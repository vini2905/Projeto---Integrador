package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.DAO;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtLogin;
	private JPasswordField txtSenha;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame. construtor
	 */
	public Login() {
		addWindowListener(new WindowAdapter() {	
			@Override
			public void windowActivated(WindowEvent e) {
				
				status();
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/img/login pizza.png")));
		setTitle("Pizzaria Lamama - Login");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.control);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(55, 136, 46, 14);
		contentPane.add(lblNewLabel);

		txtLogin = new JTextField();
		txtLogin.setBounds(123, 133, 220, 20);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(55, 187, 46, 14);
		contentPane.add(lblNewLabel_1);

		txtSenha = new JPasswordField();
		txtSenha.setBounds(123, 184, 220, 20);
		contentPane.add(txtSenha);

		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.setBackground(Color.LIGHT_GRAY);
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				logar();
			}
		});
		btnEntrar.setBounds(179, 227, 89, 23);
		contentPane.add(btnEntrar);

		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(123, 133, 220, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		lblStatus = new JLabel("");
		lblStatus.setIcon(new ImageIcon(Login.class.getResource("/img/dberror.png")));
		lblStatus.setBounds(392, 218, 32, 32);
		contentPane.add(lblStatus);
		
		lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(Login.class.getResource("/img/caixa de pizza.png")));
		lblNewLabel_2.setBounds(10, 11, 52, 48);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(Login.class.getResource("/img/sacola pizza.png")));
		lblNewLabel_3.setBounds(189, 47, 64, 64);
		contentPane.add(lblNewLabel_3);
	} 

	DAO dao = new DAO();
	private JLabel lblStatus;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;

	
	private void status() {
		try {
			
			Connection con = dao.conectar();
			
			if (con == null) {
				
				System.out.println("Erro de conex�o");
				
				lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dberror.png")));
			} else {
				System.out.println("Conex�o estabelecida com sucesso");
				
				lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dbok.png")));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	
	private void logar() {
		
		if (txtLogin.getText().isEmpty()) {
			
			JOptionPane.showMessageDialog(null, "Preencha o nome do usu�rio");
			
			txtLogin.requestFocus();
		} else {
			
			try {
					
				String read= "select * from usuarios where login=? and senha=md5(?)";
				
				Connection con = dao.conectar();
			
				PreparedStatement pst = con.prepareStatement(read);
				
				pst.setString(1, txtLogin.getText());
				pst.setString(2, txtSenha.getText());
			
				ResultSet rs = pst.executeQuery();
				
				if (rs.next()) {
				
				Principal principal = new Principal();
				principal.setVisible(true);
				this.dispose();
				} else {
				JOptionPane.showMessageDialog(null, "login e/ou senha inv�lido(s)");
				}
				con.close(); 	
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}
