package view;

import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.DAO;

import javax.swing.JButton;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class Usuario extends JDialog {
	private JTextField txtUsuario;
	private JTextField txtId;
	private JTextField txtLogin;
	private JPasswordField txtSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Usuario dialog = new Usuario();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Usuario() {
		setResizable(false);
		setTitle("Pizzaria  Lamama - Usu\u00E1rios");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Usuario.class.getResource("/img/login pizza.png")));
		setModal(true);
		setBounds(100, 100, 641, 401);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel(" Usu\u00E1rio");
		lblNewLabel.setBounds(24, 95, 73, 14);
		getContentPane().add(lblNewLabel);

		txtUsuario = new JTextField();
		txtUsuario.setBounds(107, 92, 433, 20);
		getContentPane().add(txtUsuario);
		txtUsuario.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setBounds(24, 46, 46, 14);
		getContentPane().add(lblNewLabel_1);

		txtId = new JTextField();
		txtId.setBounds(68, 43, 86, 20);
		getContentPane().add(txtId);
		txtId.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel(" Login");
		lblNewLabel_2.setBounds(24, 155, 46, 14);
		getContentPane().add(lblNewLabel_2);

		txtLogin = new JTextField();
		txtLogin.setBounds(107, 152, 313, 20);
		getContentPane().add(txtLogin);
		txtLogin.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("Senha");
		lblNewLabel_3.setBounds(24, 215, 46, 14);
		getContentPane().add(lblNewLabel_3);

		btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarUsuario();
			}
		});
		btnAdicionar.setEnabled(false);
		btnAdicionar.setToolTipText("Adicionar Usu\u00E1rio");
		btnAdicionar.setIcon(new ImageIcon(Usuario.class.getResource("/img/creat.png")));
		btnAdicionar.setBounds(120, 271, 80, 80);
		getContentPane().add(btnAdicionar);

		txtSenha = new JPasswordField();
		txtSenha.setBounds(107, 212, 314, 20);
		getContentPane().add(txtSenha);

		btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pesquisarUsuario();
			}
		});
		btnPesquisar.setToolTipText("Pesquisar Usu\u00E1rio");
		btnPesquisar.setIcon(new ImageIcon(Usuario.class.getResource("/img/read.png")));
		btnPesquisar.setBounds(221, 271, 80, 80);
		getContentPane().add(btnPesquisar);

		btnEditar = new JButton("");
		btnEditar.setEnabled(false);
		btnEditar.setToolTipText("Editar Usu\u00E1rio");
		btnEditar.setIcon(new ImageIcon(Usuario.class.getResource("/img/updates.png")));
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarUsuario();
			}
		});
		btnEditar.setBounds(326, 271, 80, 80);
		getContentPane().add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirUsuario();
			}
		});
		btnExcluir.setEnabled(false);
		btnExcluir.setToolTipText("Excluir Usu\u00E1rio");
		btnExcluir.setIcon(new ImageIcon(Usuario.class.getResource("/img/dele.png")));
		btnExcluir.setBounds(439, 271, 80, 80);
		getContentPane().add(btnExcluir);

		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(401, 46, 180, 14);
		getContentPane().add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("New label");
		lblNewLabel_5.setIcon(new ImageIcon(Usuario.class.getResource("/img/pizza usuario.png")));
		lblNewLabel_5.setBounds(492, 158, 64, 64);
		getContentPane().add(lblNewLabel_5);

	}
	DAO dao = new DAO();
	private JButton btnAdicionar;
	private JButton btnPesquisar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JLabel lblNewLabel_5;

	
	private void pesquisarUsuario() {
	
		
		if (txtId.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o ID");
			txtId.requestFocus();
		} else {
		
			String read = "select * from usuarios where id=?";
			
			try {
				
				Connection con = dao.conectar();
				
				PreparedStatement pst = con.prepareStatement(read);
				
				pst.setString(1, txtId.getText());
				
				ResultSet rs = pst.executeQuery();
				
				if (rs.next()) {
					
					txtUsuario.setText(rs.getString(2));
					txtLogin.setText(rs.getString(3));
					txtSenha.setText(rs.getString(4));
					
					btnPesquisar.setEnabled(false);
					btnEditar.setEnabled(true);
					btnExcluir.setEnabled(true);
					
					txtId.setEnabled(false);
				} else {
					JOptionPane.showMessageDialog(null, "Usu�rio inexistente");
					
					txtId.setText(null);
					
					btnAdicionar.setEnabled(true);
					btnPesquisar.setEnabled(false);
					btnEditar.setEnabled(false);
					btnExcluir.setEnabled(false);
					
					
					
					txtId.setEnabled(false);
					txtUsuario.requestFocus();

				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	
	private void adicionarUsuario() {
		
		if (txtLogin.getText().isEmpty()) {
			
			JOptionPane.showMessageDialog(null, "Preencha o Usu�rio");
			txtUsuario.requestFocus();
		} else if (txtLogin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Login");
			txtLogin.requestFocus();
		} else {
			
			String create = "insert into usuarios(usuario,login,senha) values (?,?,md5(?))";
			try {
		
				Connection con = dao.conectar();
			
				PreparedStatement pst = con.prepareStatement(create);
				
				pst.setString(1, txtUsuario.getText());
				pst.setString(2, txtLogin.getText());
				pst.setString(3, txtSenha.getText());
				
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Usu�rio adicionado com sucesso");
					
				}
			limpar();
				con.close();
			} catch (Exception e) {
				System.out.println(e);
				
			}
		}
	}

	
	private void editarUsuario() {
		
		if (txtUsuario.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "Preencha o Usu�rio");
		txtUsuario.requestFocus();
		} else if (txtLogin.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "Preencha o Login");
		txtLogin.requestFocus();
		} else {
		
		String update = "update usuarios set usuario=?,login=?,senha=md5(?) where id=?";
		try {
		
		Connection con = dao.conectar();
		
		PreparedStatement pst = con.prepareStatement(update);
		
		pst.setString(1, txtUsuario.getText());
		pst.setString(2, txtLogin.getText());
		pst.setString(3, txtSenha.getText());
		pst.setString(4, txtId.getText());
		
		int confirma = pst.executeUpdate();
		if (confirma == 1) {
		JOptionPane.showMessageDialog(null, "Dados do usu�rio alterados com sucesso");
		}
		limpar();
		con.close();
		
		
		
		} catch (java.sql.SQLIntegrityConstraintViolationException ex) {
		JOptionPane.showMessageDialog(null, "Login j� existente\nCadastre outro login");
		txtLogin.setText(null);
		txtLogin.requestFocus();
		
			
		
		} catch (Exception e) {
		System.out.println(e);
		}
		}
		}
	{
					
			
					
				}
				
			
			
			

	
	private void excluirUsuario() {
	
		int confirma = JOptionPane.showConfirmDialog(null,"Confirma a exclus�o?","Aten��o!",JOptionPane.YES_NO_OPTION);

		if(confirma == JOptionPane.YES_OPTION) {
		
		String delete = "delete from usuarios where id=?";
		try {
		
		Connection con = dao.conectar();
		
		PreparedStatement pst = con.prepareStatement(delete);
		
		pst.setString(1, txtId.getText());
		
		int verifica = pst.executeUpdate();
		if (verifica == 1) {
		JOptionPane.showMessageDialog(null, "Usu�rio exclu�do com sucesso");
		}
		limpar();
		con.close();
		} catch (Exception e) {
		System.out.println(e);
		}
		}

		
			}
	
	
	private void limpar () {
	
		txtId.setEnabled(true);

		txtId.requestFocus();
	
		txtId.setText(null);
		txtUsuario.setText(null);
		txtSenha.setText(null);
		txtLogin.setText(null);
	
		btnPesquisar.setEnabled(true);
	
		btnAdicionar.setEnabled(true);
		btnEditar.setEnabled(true);
		btnExcluir.setEnabled(true);
	}
}