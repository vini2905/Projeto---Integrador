package view;

import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.DAO;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JDesktopPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Cliente extends JDialog {
	private JTextField txtIdCli;
	private JTextField txtFoneCli;
	private JTextField txtCliente;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente dialog = new Cliente();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Cliente() {
		getContentPane().setBackground(new Color(220, 220, 220));
		setBackground(SystemColor.desktop);
		setTitle("Pizzaria Lamama - Clientes");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cliente.class.getResource("/img/login pizza.png")));
		setResizable(false);
		setModal(true);
		setBounds(100, 100, 673, 434);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(24, 191, 46, 14);
		getContentPane().add(lblNewLabel);

		txtIdCli = new JTextField();
		txtIdCli.setEnabled(false);
		txtIdCli.setBounds(80, 188, 86, 20);
		getContentPane().add(txtIdCli);
		txtIdCli.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Nome");
		lblNewLabel_1.setBounds(20, 222, 46, 14);
		getContentPane().add(lblNewLabel_1);

		txtCliente = new JTextField();
		txtCliente.setText("");
		txtCliente.setBounds(80, 219, 261, 20);
		getContentPane().add(txtCliente);
		txtCliente.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Fone");
		lblNewLabel_2.setBounds(355, 221, 46, 17);
		getContentPane().add(lblNewLabel_2);

		txtFoneCli = new JTextField();
		txtFoneCli.setBounds(411, 219, 97, 20);
		getContentPane().add(txtFoneCli);
		txtFoneCli.setColumns(10);

		btnAdicionarCliente = new JButton("");
		btnAdicionarCliente.setToolTipText("Adicionar Cliente");
		btnAdicionarCliente.setIcon(new ImageIcon(Cliente.class.getResource("/img/add clients.png")));
		btnAdicionarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarCliente();
			}
		});
		btnAdicionarCliente.setBounds(80, 308, 80, 80);
		getContentPane().add(btnAdicionarCliente);

		txtPesquisar = new JTextField();
		txtPesquisar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
			
				pesquisarCliente();
			}
		});
		txtPesquisar.setBounds(10, 11, 212, 20);
		getContentPane().add(txtPesquisar);
		txtPesquisar.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Cliente.class.getResource("/img/searchs.png")));
		lblNewLabel_3.setBounds(238, 11, 32, 32);
		getContentPane().add(lblNewLabel_3);

		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(10, 60, 579, 100);
		getContentPane().add(desktopPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 579, 99);
		desktopPane.add(scrollPane);

		tableCliente = new JTable();
		tableCliente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				setarCampos();
			}
		});
		scrollPane.setViewportView(tableCliente);

		btnEditarCliente = new JButton("");
		btnEditarCliente.setEnabled(false);
		btnEditarCliente.setToolTipText("Editar Cliente");
		btnEditarCliente.setIcon(new ImageIcon(Cliente.class.getResource("/img/edit client.png")));
		btnEditarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarCliente();

			}

		});
		btnEditarCliente.setBounds(192, 308, 80, 80);
		getContentPane().add(btnEditarCliente);

		btnExcluirCliente = new JButton("");
		btnExcluirCliente.setEnabled(false);
		btnExcluirCliente.setToolTipText("Excluir Cliente");
		btnExcluirCliente.setIcon(new ImageIcon(Cliente.class.getResource("/img/delete clientes.png")));
		btnExcluirCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirCliente();
			}

		});
		btnExcluirCliente.setBounds(304, 308, 80, 80);
		getContentPane().add(btnExcluirCliente);
		
		txtEndereco = new JTextField();
		txtEndereco.setBounds(421, 255, 116, 20);
		getContentPane().add(txtEndereco);
		txtEndereco.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Endereco");
		lblNewLabel_5.setBounds(355, 256, 60, 14);
		getContentPane().add(lblNewLabel_5);
		
		txtNumero = new JTextField();
		txtNumero.setBounds(574, 219, 46, 20);
		getContentPane().add(txtNumero);
		txtNumero.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Numero");
		lblNewLabel_6.setBounds(518, 222, 46, 14);
		getContentPane().add(lblNewLabel_6);
		
		txtBairro = new JTextField();
		txtBairro.setBounds(80, 253, 86, 20);
		getContentPane().add(txtBairro);
		txtBairro.setColumns(10);
		
		lblNewLabel_7 = new JLabel("Bairro");
		lblNewLabel_7.setBounds(24, 256, 46, 14);
		getContentPane().add(lblNewLabel_7);

	}
	DAO dao = new DAO();
	private JTextField txtPesquisar;
	private JTable tableCliente;
	private JButton btnEditarCliente;
	private JButton btnExcluirCliente;
	private JButton btnAdicionarCliente;
	private JTextField txtNumero;
	private JTextField txtBairro;
	private JLabel lblNewLabel_7;
	private JTextField txtEndereco;

	
	private void adicionarCliente() {
		
		if (txtCliente.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "preencha o nome do cliente ");
			txtCliente.requestFocus();
		} else if (txtFoneCli.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o fone do cliente ");
			txtFoneCli.requestFocus();
			
		} else if (txtEndereco.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o endereco do cliente ");
			txtEndereco.requestFocus();
			
		} else if (txtNumero.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o numero do cliente ");
			txtNumero.requestFocus();
			
		} else if (txtBairro.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o bairro do cliente ");
			txtBairro.requestFocus();
			
				
			
			

		} else {
			
			String create = "insert into clientes (nome,endereco,numero,bairro,fone) values (?,?,?,?,?)";
			try {
				
				Connection con = dao.conectar();
				
				PreparedStatement pst = con.prepareStatement(create);
				

				pst.setString(1, txtCliente.getText());
				pst.setString(2, txtFoneCli.getText());
				pst.setString(3, txtEndereco.getText());
				pst.setString(4, txtNumero.getText());
				pst.setString(5, txtBairro.getText());
				

				
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Cliente adicionado com sucesso.");

				}
				
				con.close();
				
				limpar();
			} catch (Exception e) {
				System.out.println(e);

			}
		}
	}

	
	private void editarCliente() {
		
		if (txtCliente.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Cliente");
			txtCliente.requestFocus();
		} else if (txtEndereco.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o endereco");
			txtEndereco.requestFocus();
		} else if (txtNumero.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o numero");
			txtNumero.requestFocus();
		} else if (txtBairro.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Bairro");
			txtBairro.requestFocus();
			} else if (txtFoneCli.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o FoneCli");
			txtFoneCli.requestFocus();
		} else {
			
			String update = "update clientes set nome=?,endereco=?,numero=?,bairro=?,fone=? where idcli=?";
			try {
				
				Connection con = dao.conectar();
				
				PreparedStatement pst = con.prepareStatement(update);
				
				pst.setString(1, txtCliente.getText());
				pst.setString(2, txtEndereco.getText());
				pst.setString(3, txtNumero.getText());
				pst.setString(4, txtBairro.getText());
				pst.setString(5, txtFoneCli.getText());
				pst.setString(6, txtIdCli.getText());
				
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Dados do cliente alterados com sucesso");
				}
				limpar();
				con.close();

				
				con.close();
				
				limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	
	private void excluirCliente() {
		
		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o?", "Aten��o!",
				JOptionPane.YES_NO_OPTION);
		

		if (confirma == JOptionPane.YES_OPTION) {
			
			String delete = "delete from clientes where idcli=?";
			try {
				
				Connection con = dao.conectar();
				
				PreparedStatement pst = con.prepareStatement(delete);
				
				pst.setString(1, txtIdCli.getText());
				
				int verifica = pst.executeUpdate();
				if (verifica == 1) {
					JOptionPane.showMessageDialog(null, "Cliente exclu�do com sucesso");
					
					
				
				}
				limpar();
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	
	
	
	private void pesquisarCliente() {
		String read = "select * from clientes where nome like ? order by nome";
		try {
			System.out.println("testando o evento");
			
			Connection con = dao.conectar();
		
			PreparedStatement pst = con.prepareStatement(read);
			
			pst.setString(1, txtPesquisar.getText() + "%");
			
			ResultSet rs = pst.executeQuery();
			
			tableCliente.setModel(DbUtils.resultSetToTableModel(rs));

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	
	
	
	private void setarCampos() {
	int setar = tableCliente.getSelectedRow();
	
	
	txtIdCli.setText(tableCliente.getModel().getValueAt(setar, 0).toString());
	txtCliente.setText(tableCliente.getModel().getValueAt(setar, 1).toString());
	txtEndereco.setText(tableCliente.getModel().getValueAt(setar, 2).toString());
	txtNumero.setText(tableCliente.getModel().getValueAt(setar, 3).toString());
	txtBairro.setText(tableCliente.getModel().getValueAt(setar, 4).toString());
	txtFoneCli.setText(tableCliente.getModel().getValueAt(setar, 5).toString());
	
	btnEditarCliente.setEnabled(true);
	btnExcluirCliente.setEnabled(true);
	btnAdicionarCliente.setEnabled(false);
	}
		
		
		
	

	
	private void limpar() {
	
	txtCliente.setText(null);
	txtFoneCli.setText(null);
	txtPesquisar.setText(null);
	txtEndereco.setText(null);
	txtNumero.setText(null);
	txtBairro.setText(null);
	btnAdicionarCliente.setEnabled(true);
	btnEditarCliente.setEnabled(false);
	btnExcluirCliente.setEnabled(false);

	}
		}
	

